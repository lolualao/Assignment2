% Elec 4700
% Assignment 2
% 100977279
% 23rd feduary 2020

clear all
close all

Wid = 30;
len = 45; 
% Electrostatic potential in a rectangle
% using the finite difference method for solving electrostatic potential
% for wid and len


Gmatrix = sparse((Wid * len), (Wid * len));
F = zeros((Wid*len),1);
Vmatrix = zeros(Wid,len); 

vo = 1;

for i = 1:Wid
    for j = 1:len
       k = j + (i - 1) * len;
       Widm = i + (j - 2) * Wid;  
       Widp = i + j * Wid; 
      
       if i == 1
            Gmatrix(k, :) = 0;
            Gmatrix(k, k) = 1;
            F(k) = vo;
            
        elseif i == Wid
            Gmatrix(k, :) = 0;
            Gmatrix(k, k) = 1;
             F(k) = 0;
        elseif j == 1 && i > 1 && i < Wid
          
            Gmatrix(k, k) = -3;
            Gmatrix(k, k - len) = 1;
            Gmatrix(k, k + len) = 1;
            Gmatrix(k, k - 1) = 1;
           
        elseif j == len && i > 1 && i < Wid
      
            Gmatrix(k, k) = -3;
            Gmatrix(k, k - len) = 1;
            Gmatrix(k, k + len) = 1;
            Gmatrix(k, k + 1) = 1;
          
        else
  
            Gmatrix(k, k) = -4;
            Gmatrix(k, k - len) = 1;
            Gmatrix(k, k + len) = 1;
            Gmatrix(k, k - 1) = 1;
            Gmatrix(k, k + 1) = 1;
            F(k) = 0;
        end
    end
    
end



figure (1);
spy(Gmatrix);

V = Gmatrix\F;
figure (2);
Vmatrix = zeros(Wid, len);

for i = 1:Wid

    for j = 1:len
        n = j + (i - 1) * len;
        Vmatrix(i, j) = V(n);
    end
end
   
mesh(Vmatrix);









% question 1b
len = 45; 
wid = 30; 
Gmatrix = sparse(len*wid, wid*len);
F = zeros(len*wid,1);
map = @(i,j) j + (i - 1)*wid;
for i=1:len
    
    for j=1:wid
        n = map(i,j);
        lenm = map(i-1,j);
        lenp = map(i+1,j);
        widm = map(i,j-1);
        widp = map(i,j+1);
        
      
        if i == 1
            Gmatrix(n,:) = 0;
            Gmatrix(n,n) = 1;
            F(n) = 1;
    
        elseif i == len
            Gmatrix(n,:) = 0;
            Gmatrix(n,n) = 1;
            F(n) = 1;
        elseif j == 1
           Gmatrix(n,:) = 0;
           Gmatrix(n,n) = 1;
            F(n) = 0;
        elseif j == wid
            Gmatrix(n,:) = 0;
            Gmatrix(n,n) = 1;
            F(n) = 0;
        else
            Gmatrix(n,:) = 0;
            Gmatrix(n,n) = -4;
            Gmatrix(n,lenm) = 1;
            Gmatrix(n,lenp) = 1;
            Gmatrix(n,widm) = 1;
            Gmatrix(n,widp) = 1;
        end
    end
end


Z = Gmatrix\F ;

% Setting up a surf plot
surfs = zeros(len,wid);
for i = 1:len
    for j = 1:wid
        n = map(i,j);
        surfs (i,j) = Z(n);
    end
end

%Plot
figure(3)
mesh(surfs)
title('Electrostatic Potential in Rectangular in numerical');



zone = zeros(45, 30);
a = 45;
b = 15;
W = linspace(-15,15,30);
l = linspace(0,45,45);
[x, y] = meshgrid(W, l);
for n = 1:2:1000
    
    zone = (zone + (4 * vo/pi) .* (cosh((n * pi * x)/a) .* sin((n * pi * y)/a)) ./ (n * cosh((n * pi * b)/a)));
    figure(4);
    mesh(zone);
    title('Electrostatic Potential in Rectangular in analytical');

    
 end
           
